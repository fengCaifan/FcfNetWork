//
//  Net+Signature.swift
//  Alamofire
//
//  Created by 冯才凡 on 2020/11/24.
//

import Foundation



/*
 签名方式 （Todo）
 */
extension Net {
     public enum SignEncryption: String {
        case none              // 没有签名
        case AES               // AES
     }
    
    
}
