//
//  BTTool.swift
//  Alamofire
//
//  Created by 冯才凡 on 2020/11/26.
//

import Foundation


//
@objc public extension NSNotification {
    @objc static var NetCode_410 : Name {
        return Name("NetCode_410")
    }
    
    @objc static var NetCode_411 : Name {
        return Name("NetCode_411")
    }
    
    @objc static var NetStatuChange : Name {
        return Name("NetStatuChange")
    }
}

